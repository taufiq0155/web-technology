<?php
session_start();
$mysqli = new mysqli("localhost", "root", "", "photo_gallery_db");

$success_message = '';
$error_message = '';

if (!isset($_SESSION['success_message'])) {
    $_SESSION['success_message'] = '';
}
if (!isset($_SESSION['error_message'])) {
    $_SESSION['error_message'] = '';
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $email = $mysqli->real_escape_string($_POST['email']);
    $password = $_POST['password'];

    $result = $mysqli->query("SELECT * FROM users WHERE email='$email'");
    if ($result->num_rows == 1) {
        $user = $result->fetch_assoc();
        if (password_verify($password, $user['password'])) {
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['success_message'] = "Login successful!";
            header("Location: upload.php");
            exit();
        } else {
            $_SESSION['error_message'] = "Incorrect password.";
        }
    } else {
        $_SESSION['error_message'] = "User not found.";
    }
    header("Location: index.php");
    exit();
}

$success_message = $_SESSION['success_message'];
$error_message = $_SESSION['error_message'];

$_SESSION['success_message'] = '';
$_SESSION['error_message'] = '';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="stylesheet" href="styles.css">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
</head>
<body>
    <div class="login-container">
        <h2>Login</h2>
        <?php if ($success_message): ?>
            <div class="success-message"><?php echo $success_message; ?></div>
        <?php endif; ?>
        <?php if ($error_message): ?>
            <div class="error-message"><?php echo $error_message; ?></div>
        <?php endif; ?>
        <form method="POST">
            <input type="email" name="email" placeholder="Email" required>
            <input type="password" name="password" placeholder="Password" required>
            <input type="submit" value="Login">
        </form>
        <button onclick="window.location.href='register.php'">Register</button>
    </div>
</body>
</html>
