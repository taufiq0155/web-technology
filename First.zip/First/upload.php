<?php
session_start();
$mysqli = new mysqli("localhost", "root", "", "photo_gallery_db");

if (!isset($_SESSION['user_id'])) {
    header("Location: index.php");
    exit();
}

$user_id = $_SESSION['user_id'];

if (!isset($_SESSION['success_message'])) {
    $_SESSION['success_message'] = '';
}
if (!isset($_SESSION['error_message'])) {
    $_SESSION['error_message'] = '';
}

$success_message = $_SESSION['success_message'];
$error_message = $_SESSION['error_message'];

$_SESSION['success_message'] = '';
$_SESSION['error_message'] = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_FILES['photo'])) {
    $photo = $_FILES['photo'];
    $upload_dir = 'uploads/';
    $photo_path = $upload_dir . basename($photo['name']);
    
    $result = $mysqli->query("SELECT * FROM photos WHERE user_id='$user_id' AND photo_path='$photo_path'");
    if ($result->num_rows > 0) {
        $_SESSION['error_message'] = "Image is already in the database.";
        header("Location: upload.php");
        exit();
    }
    
    if (move_uploaded_file($photo['tmp_name'], $photo_path)) {
        $mysqli->query("INSERT INTO photos (user_id, photo_path) VALUES ('$user_id', '$photo_path')");
        $_SESSION['success_message'] = "Photo uploaded successfully!";
        header("Location: upload.php");
        exit();
    } else {
        $_SESSION['error_message'] = "Failed to upload photo.";
        header("Location: upload.php");
        exit();
    }
}

if (isset($_GET['delete'])) {
    $photo_id = $_GET['delete'];
    $result = $mysqli->query("SELECT * FROM photos WHERE id='$photo_id' AND user_id='$user_id'");
    if ($result->num_rows > 0) {
        $photo = $result->fetch_assoc();
        unlink($photo['photo_path']); 
        $mysqli->query("DELETE FROM photos WHERE id='$photo_id'");
        $_SESSION['success_message'] = "Photo deleted successfully.";
    } else {
        $_SESSION['error_message'] = "Failed to delete photo.";
    }
    header("Location: upload.php");
    exit();
}

$user_result = $mysqli->query("SELECT username FROM users WHERE id='$user_id'");
$user = $user_result->fetch_assoc();
$username = $user['username'];

$photos = $mysqli->query("SELECT * FROM photos WHERE user_id='$user_id'");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="stylesheet" href="styles.css">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Photo Upload</title>
</head>
<body>
    <div class="upload-container">
        <h2>Upload Photo</h2>
        
        <?php if ($success_message): ?>
            <div class="success-message"><?php echo $success_message; ?></div>
        <?php endif; ?>
        <?php if ($error_message): ?>
            <div class="error-message"><?php echo $error_message; ?></div>
        <?php endif; ?>
        
        <form method="POST" enctype="multipart/form-data">
            <input type="file" name="photo" required>
            <input type="submit" value="Upload Photo">
        </form>


        <a class="logout" href="logout.php">Logout</a>

        <h3><?php echo htmlspecialchars($username); ?>'s Photos</h3>
        <?php if ($photos->num_rows > 0): ?>
            <div class="gallery">
                <?php while ($photo = $photos->fetch_assoc()): ?>
                    <div class="gallery-item">
                        <img src="<?php echo htmlspecialchars($photo['photo_path']); ?>" alt="User Photo">
                        <button class="delete" onclick="window.location.href='upload.php?delete=<?php echo $photo['id']; ?>'"></button>
                    </div>
                <?php endwhile; ?>
            </div>
        <?php else: ?>
            <p>No photos uploaded yet.</p>
        <?php endif; ?>
    </div>
</body>
</html>
