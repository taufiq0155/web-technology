<?php
session_start();
$mysqli = new mysqli("localhost", "root", "", "photo_gallery_db");

if (!isset($_SESSION['success_message'])) {
    $_SESSION['success_message'] = '';
}
if (!isset($_SESSION['error_message'])) {
    $_SESSION['error_message'] = '';
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $email = $mysqli->real_escape_string($_POST['email']);
    $username = $mysqli->real_escape_string($_POST['username']);
    $password = password_hash($_POST['password'], PASSWORD_BCRYPT);

    $result = $mysqli->query("SELECT * FROM users WHERE email='$email'");
    if ($result->num_rows > 0) {
        $_SESSION['error_message'] = "Email is already registered. Please use a different email.";
    } else {
        $query = "INSERT INTO users (email, username, password) VALUES ('$email', '$username', '$password')";
        
        if ($mysqli->query($query)) {
            $_SESSION['success_message'] = "Registration successful! Redirecting to <a href='index.php'>Login page</a>...";
            header("Location: register.php"); 
            exit();
        } else {
            $_SESSION['error_message'] = "Error: " . $mysqli->error;
        }
    }

  
    header("Location: register.php");
    exit();
}


$success_message = $_SESSION['success_message'];
$error_message = $_SESSION['error_message'];


$_SESSION['success_message'] = '';
$_SESSION['error_message'] = '';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="stylesheet" href="styles.css">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register</title>
</head>
<body>
    <div class="register-container">
        <h2>Register</h2>
        <?php if ($success_message): ?>
            <div class="success-message"><?php echo $success_message; ?></div>
        <?php endif; ?>
        <?php if ($error_message): ?>
            <div class="error-message"><?php echo $error_message; ?></div>
        <?php endif; ?>
        <form method="POST">
            <input type="email" name="email" placeholder="Email" required>
            <input type="text" name="username" placeholder="Username" required>
            <input type="password" name="password" placeholder="Password" required>
            <input type="submit" value="Register">
        </form>
        <button onclick="window.location.href='index.php'">Back to Login</button>
        
       
       
    </div>
</body>
</html>
